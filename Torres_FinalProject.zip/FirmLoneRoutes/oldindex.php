<!DOCTYPE html>
<html lang="en">
  <head>
    <title>PHP Test [Eric Torres] </title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
  </head>
  <body>
    <div id="container">
    <div id="header">
    <h1> Homepage of Eric Torres </h1>
    </div>
      <div id= "content">
        <div id="nav">
    <h2>Navigation </h2>
    <ul class= "menu">
     <li><a href="index.php">Home (index.php)</a></li>
     <li><a href="Torres_Assignment1.php">Assignment 1</a></li>
     <li><a href="Torres_Assignment2.php">Assignment 2</a></li>
     <li><a href="Torres_Assignment3.php">Assignment 3</a></li>
     <li><a href="index.php">Assignment 4</a></li>
     <li><a href="#">Assignment 5</a></li>
     <li><a href="#">Final Project</a></li>
     <li><a href="#">Privacy Policy</a></li>
  
    </ul>
        </div>
<div id= "main">
<p>
  Future home of my navigation links to help Dr. McMilan (Dr. T) find my homework files for grading.
</p>
</div>
        
    <?php
    // This is a comment to help me explain my code.
    $aVariable = 77;
    echo("<p>The value of this variable is $aVariable</p>");
    ?>
    <?php echo '<p>Hello World</p>'; ?> 

    
</html>